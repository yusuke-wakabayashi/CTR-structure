# CTR-tools

## 概要

交換モンテカルロ法による表面構造精密化ソフトウェア
CTR-structureのインプットファイルに関する
ユーティリティツール

## 動作環境・ライブラリ

Python3.9にて動作確認

下記のライブラリを使用
- numpy==1.21.2
- periodictable==1.6.0

## ファイル構成

- src

  ソースコードディレクトリ

  - ctr_tool.py

    CTR-toolのメインライブラリ

  - out_xyz.py

    CTR-structureのインプットファイルを入力として初期状態のXYZファイルを出力するスクリプト

  - check_ctr.py

    CTR-structureのインプットファイルを入力としてその中身に問題がないかをチェックし、
    その結果を標準出力に出力するスクリプト

  - test_load_json.py

    CTR-toolが出力するJSON形式をロードするテストスクリプト

- sample

  サンプルディレクトリ
  sample1, sample2, sample3, sample4それぞれの下にサンプルのsubstrate.dat, surf.datを配置

## 使い方

### out_xyz.py

out_xyz.pyは、CTR-structureの基板、表面のインプットファイルを
入力としてVESTA等で読み込み可能なXYZ形式のファイルを出力する。

例として、sample/sample1ディレクトリに移動し、src/out_xyz.pyを実行する。

```
cd sample/sample1
python ../../src/out_xyz.py substrate.dat surf.dat > sample.xyz
```

上記コマンドで、下記のXYZファイルが生成される

```
65
substrate.dat + surf.dat, 1 x 1 (CTR-tool)
Sr -0.000000 -0.000000 -3.905000
Ti 1.952500 1.952500 -1.952500
O 1.952500 1.952500 -3.905000
O 0.000000 1.952500 -1.952500
O 1.952500 -0.000000 -1.952500
Sr 0.000000 0.000000 0.000000
Ti 1.952500 1.952500 1.952500
O 1.952500 1.952500 0.000000
O 0.000000 1.952500 1.952500
O 1.952500 0.000000 1.952500
...途中略
La 0.000000 0.000000 42.955000
Al 1.952500 1.952500 44.907500
O 1.952500 1.952500 42.955000
O 0.000000 1.952500 44.907500
O 1.952500 0.000000 44.907500
```

上記の構造ファイルを結晶構造可視化ソフトウェアVESTA
( https://jp-minerals.org/vesta/jp/ )
を用いて可視化すると下記のようになる。

<img src="images/sample.png" width="50%">

また、x方向、y方向（substrate.datから定義される格子ベクトルの1つ目と2つ目の方向）
に格子を増やしたい場合は、-x, -yオプションを用いると良い

```
python ../../src/out_xyz.py -x 2 -y 3 substrate.dat surf.dat > sample_2x3.xyz
```

上記の場合は2 x 3の超格子を生成し、XYZ構造ファイルを出力する。

```
90
substrate.dat + surf.dat, 2 x 3 (CTR-tool)
Sr -0.000000 -0.000000 -3.905000
Ti 1.952500 1.952500 -1.952500
O 1.952500 1.952500 -3.905000
O 0.000000 1.952500 -1.952500
O 1.952500 -0.000000 -1.952500
Sr 0.000000 3.905000 -3.905000
Ti 1.952500 5.857500 -1.952500
O 1.952500 5.857500 -3.905000
O 0.000000 5.857500 -1.952500
O 1.952500 3.905000 -1.952500
...途中略
La 3.905000 7.810000 42.955000
Al 5.857500 9.762500 44.907500
O 5.857500 9.762500 42.955000
O 3.905000 9.762500 44.907500
O 5.857500 7.810000 44.907500
```

上記の構造ファイルをVESTAを用いて可視化すると下記のようになる。

<img src="images/sample_2x3.png" width="50%">

**cif出力機能**

--cifオプションを付ける事でCIF形式による出力が可能。
同じサイトに複数原子が存在しうる場合はこちらを用いる事で
構造を確認可能。

```
python ../../src/out_xyz.py substrate.dat surf.dat --cif > sample.cif
```

### check_ctr.py

check_ctr.pyは、CTR-structureの基板、表面のインプットファイルを
入力としてその内容をチェックし、標準出力にチェック結果を出力する。

例として、sampleディレクトリに移動し、src/check_ctr.pyを実行する。

```
cd sample/sample1
python ../../src/check_ctr.py substrate.dat surf.dat
```

下記のように出力される

```
Checking substrate and surface data...
    Checking distance between substrate and surface...
    OK.
    Checking distance in substrate...
    OK.
    Checking distance in surface...
    OK.
Finished.
```

ここで、-t オプションを用いる事で、距離の閾値を変更する事が出来る。
（単位Å、オプションを用いない場合は1Åとなる）

例えば、

```
python ../../src/check_ctr.py substrate.dat surf.dat -t 4.0
```

とすると、距離が4.0Åより近い場合に警告が出るようになる。

```
Checking substrate and surface data...
    Checking distance between substrate and surface...
    Warning: substrate (1) and surface ([4]) are too close
    Checking distance in substrate...
    Warning: substrate (1) and (2) are too close
    Warning: substrate (1) and (3) are too close
    Warning: substrate (1) and (4) are too close
    Checking distance in surface...
    Warning: surface ([2, 3]) and ([4]) are too close
    Warning: surface ([2, 3]) and ([5]) are too close
（途中略）
    Warning: surface ([79, 80]) and ([82]) are too close
    Warning: surface ([79, 80]) and ([83]) are too close
Finished.
```

上記の場合、まず基板と表面の原子距離が判定され、
基板ファイルの原子1と表面ファイルの原子4の距離が近いという警告が出る。
（表面ファイルの原子については、同じ場所を占める原子が
複数あり得るためリスト表記となっている）

以下、基板ファイル内の原子距離、表面ファイル内の
原子距離についての判定がなされる。

**座標出力機能**

--out_coordオプションを付ける事でdatファイル内の
座標データを出力する事が出来る。

```
python ../../src/check_ctr.py substrate.dat surf.dat --out_coord
```

下記のように出力される。表面データについては複数の原子種が同じ場所に
割り当てられる可能性があるため、リストで出力される。
また、リスト内の元素記号の後ろにsurf.dat内での番号が付与される。

```
Output atomic species and coordinates in substrate.dat
    0: Sr at (-0.00000, -0.00000, -3.90500)
    1: Ti at (1.95250, 1.95250, -1.95250)
    2: O at (1.95250, 1.95250, -3.90500)
    3: O at (0.00000, 1.95250, -1.95250)
    4: O at (1.95250, -0.00000, -1.95250)

Output atomic species and coordinates in surf.dat
    0: ['Sr(0)', 'La(1)'] at (0.00000, 0.00000, 0.00000)
    1: ['Ti(2)', 'Al(3)'] at (1.95250, 1.95250, 1.95250)
    2: ['O(4)'] at (1.95250, 1.95250, 0.00000)
    3: ['O(5)'] at (0.00000, 1.95250, 1.95250)
    4: ['O(6)'] at (1.95250, 0.00000, 1.95250)
...（以下略）
```
