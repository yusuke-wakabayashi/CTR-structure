"""
ctr_tool.py
Functions and classes for checking the parameter files for CTR-structure
"""
import json
import math
import numpy as np
import periodictable as pt

def get_lattice_vec(dic_lattice):
    """
    Get lattice vectors from parameters of fractional coordinate system

    Argument
    --------
    dic_lattice : dict
        Dictionary of the substrate lattice
    
    Return
    ------
    [vec_x, vec_y, vec_z] : list(np.array)
        List of lattice vectors
    """
    a = dic_lattice["a"]
    b = dic_lattice["b"]
    c = dic_lattice["c"]
    alp = dic_lattice["alpha"]
    bet = dic_lattice["beta"]
    gam = dic_lattice["gamma"]

    cos_a = math.cos(alp*math.pi/180)
    cos_b = math.cos(bet*math.pi/180)
    cos_c = math.cos(gam*math.pi/180)
    sin_c = math.sin(gam*math.pi/180)
    omega = math.sqrt(1-cos_a**2-cos_b**2-cos_c**2-2*cos_a*cos_b*cos_c)

    vec_x = np.array([a, 0.0, 0.0])
    vec_y = np.array([b*cos_c, b*sin_c, 0.0])
    vec_z = np.array([c*cos_b, c*(cos_a-cos_b*cos_c)/sin_c, c*omega/sin_c])
    return [vec_x, vec_y, vec_z]

def get_coords_sub(dic_sub, under_ab_plane=True):
    """
    Get coordinates, atomic species, and lattice vectors for the substrate

    Arguments
    ---------
    dic_sub : dict
        Dictionary of the substrate
    under_xy_plane : bool, default True
        Whether the coordinate of the substrate are under the ab-plane or not

    Returns
    -------
    atom_coords : list(np.array)
        Coordinates of atoms of the substrate
    atom_species : list(str)
        Atomic species of the substrate
    vec : list(np.array)
        Lattice vectors of the substrate
    """
    vec = get_lattice_vec(dic_sub["lattice"])
    atom_coords = []
    atom_species = []
    dz = 0.0
    if under_ab_plane:
        dz = 1.0
    for atom in dic_sub["atoms"]:
        x_cart = atom["x"]*vec[0] + atom["y"]*vec[1] + (atom["z"]-dz)*vec[2]
        atom_coords.append(x_cart)
        atom_species.append(str(pt.elements[atom["atomic_number"]]))

    return atom_coords, atom_species, vec

def get_init_coords_surf(dic_surf, vec):
    """
    Get coordinates, atomic species, and occupations for the surface

    Arguments
    ---------
    dic_surf : dict
        Dictionary of the surface
    vec: list(np.array)
        Lattice vector of the substrate

    Returns
    -------
    atom_coords : list(np.array)
        Coordinates of atoms of the surface
    atom_coords_frac : list(list)
        Fractional coordinates of atoms of the surface
    atom_species : list(str)
        Atomic species of the surface
    atom_occup : list(float)
        Occupancy list of the surface atoms
    """
    atom_coords = []
    atom_coords_frac = []
    atom_species = []
    atom_occup = []
    if vec == []:
        print("Warning: Latiice vector is empty. Use get_coords_substrate.")
        return atom_coords, atom_species, atom_occup
    else:
        for atom in dic_surf["atoms"]:
            for i in range(atom["N"]):
                x_cart = atom["x"]*vec[0] + atom["y"]*vec[1] + (atom["z"]+atom["d"]*i)*vec[2]
                x_frac = [atom["x"], atom["y"], atom["z"]+atom["d"]*i]
                atom_coords.append(x_cart)
                atom_coords_frac.append(x_frac)
                atom_species.append(str(pt.elements[atom["AtmNum"]]))
                atom_occup.append(atom["foccf"])

        return atom_coords, atom_coords_frac, atom_species, atom_occup

def get_dist(x1, x2):
    """
    Get distance between two vectors

    Arguments
    ---------
    x1 : list
        vector 1
    x2 : list
        vector 2

    Return
    ------
    np.linalg.norm(np.array(x1)-np.array(x2)) : float
        Distance between x1 and x2
    """
    return np.linalg.norm(np.array(x1)-np.array(x2))

def have_same_point(x1, li, eps=1e-10):
    """
    Check the list have the same vector as a given vector

    Arguments
    ---------
    x1 : list
        A given vector
    li : list(list)
        List of vectors
    eps : float, default 1e-10
        Tolerance of the gap

    Retrurns
    --------
    n : int
        Index for the vector x1
    True or False : bool
        li have the same vector as x1 or not
    """
    n = len(li)
    for i in range(n):
        dx = get_dist(x1, li[n-1-i])
        if dx < eps:
            return n-1-i, True
    return n, False

def get_position_list(coords):
    """
    Get the position list of the surface from coordinates of the surface

    Argument
    --------
    coords : list(list)
        Coordinates of atoms of the surface

    Returns
    -------
    position_list : list(np.array)
        Position list in coords
    index_list : list(list)
        Index list of surf atoms.
        Atoms of indices of i-th list are located at i-th position of position_list
    """
    position_list = []
    index_list = []
    for i, coord in enumerate(coords):
        ind, have = have_same_point(coord, position_list)
        if have:
            index_list[ind].append(i)
        else:
            position_list.append(coord)
            index_list.append([i])
    return position_list, index_list

class CTRtool():
    """
    Class for importing the parameter files for CTR-structure

    Attributes
    ----------
    dic_sub : dict
        dictionary for substrate
    dic_surf : dict
        dictionary for surface
    lat_vec : list(np.array)
        lattice vectors of substrate
    """
    def __init__(self, substrate="", surf=""):
        """
        Initialize CTRtool class

        Arguments
        ---------
        substrate : str, default ""
            substrate data file for CTR-structure
        surf : str, default ""
            surface data file for CTR-structure
        """
        # Process substrate data
        if substrate != "":
            self._read_substrate(substrate)
            self._get_coords_substrate()
        else:
            self.dic_sub = {}
            self.lat_vec = []

        # Process surface data
        if surf != "":
            self._read_surf(surf)
            self._get_init_coords_surf()
            self._get_position_list_surf_init()
            self._get_species_surf_init()
        else:
            self.dic_surf = {}

    def _read_substrate(self, substrate):
        """
        Read substrate file for CTR-structure and make self.dic_sub

        Arguments
        ---------
        substrate : str
            substrate data file for CTR-structure
        """
        with open(substrate) as f:
            lines = f.readlines()
        lattice_dat = [float(x) for x in lines[0].split("\t")]
        dic_lattice = {}
        dic_lattice_keys = ["a", "b", "c", "alpha", "beta", "gamma"]
        for i, key in enumerate(dic_lattice_keys):
            dic_lattice[key] = lattice_dat[i]

        dic_atom_keys = ["index", "ext", "atomic_number", "x", "y", "z", "B", "occupancy"]
        list_atoms = []
        for line in lines[1:]:
            list_tmp = line.split("\t")
            if len(list_tmp) == len(dic_atom_keys):
                atom_dat = [int(x) for x in list_tmp[:3]] + [float(x) for x in list_tmp[3:]]
                dic_atom = {}
                for i, key in enumerate(dic_atom_keys):
                    dic_atom[key] = atom_dat[i]
                list_atoms.append(dic_atom)

        dic_substrate = {}
        dic_substrate["lattice"] = dic_lattice
        dic_substrate["atoms"] = list_atoms
        self.dic_sub = dic_substrate

    def _get_coords_substrate(self):
        """
        Get coodinates, atomic species, and lattice vectors for substrate
        Coordinates and species are saved in self.dic_sub, 
        and lattice vectors are saved in self.lat_vec
        """
        self.dic_sub["coords"], self.dic_sub["species"], self.lat_vec = get_coords_sub(self.dic_sub)

    def _read_surf(self, surf):
        """
        Read surface file for CTR-structure and make self.dic_surf

        Arguments
        ---------
        surf : str
            surface data file for CTR-structure
        """
        with open(surf) as f:
            lines = f.readlines()
        surf_dat = [line.rstrip("\r\n").split("\t") for line in lines]
        params = surf_dat[0]
        dic_surf_params = {}
        dic_surf_params[params[0]] = float(params[1])
        dic_surf_params[params[2]] = int(params[3])
        dic_surf_params[params[4]] = float(params[5])
        dic_surf_params[params[6]] = int(params[7])
        dic_surf_params[params[8]] = float(params[9])
        dic_surf_params[params[10]] = int(params[11])
        dic_surf_params[params[12]] = float(params[13])
        dic_surf_params[params[14]] = int(params[15])

        list_atoms = []
        keys = surf_dat[1]
        types = ["float" for i in range(len(keys))]
        ind_list_int = [0, 1, 2, 11, 12, 14, 15, 17, 18, 20, 21, 23, 24, 26, 27, 29, 30]
        for ind in ind_list_int:
            types[ind] = "int"
        types[10] = "bin"

        for dat in surf_dat[2:]:
            if len(dat) == len(keys):
                dic_atom = {}
                for i, x in enumerate(dat):
                    if x == "":
                        dic_atom[keys[i]] = None
                    elif types[i] == "float":
                        dic_atom[keys[i]] = float(x)
                    elif types[i] == "int":
                        dic_atom[keys[i]] = int(x)
                    elif types[i] == "bin":
                        dic_atom[keys[i]] = str(x).zfill(7)
                    else:
                        dic_atom[keys[i]] = None
                list_atoms.append(dic_atom)

        dic_surf = {}
        dic_surf["params"] = dic_surf_params
        dic_surf["atoms"] = list_atoms
        self.dic_surf = dic_surf

    def _get_init_coords_surf(self):
        """
        Get initial coordinates, species, occupancies for surface atoms
        These are saved in self.dic_surf
        """
        coords_surf_init, coords_surf_frac_init, species_surf, occup_surf_init = get_init_coords_surf(self.dic_surf, self.lat_vec)
        self.dic_surf["coords_init"] = coords_surf_init
        self.dic_surf["coords_frac_init"] = coords_surf_frac_init
        self.dic_surf["species"] = species_surf
        self.dic_surf["occup_init"] = occup_surf_init

    def _get_position_list_surf_init(self):
        """
        Get initial indepent position list and index list for surface
        """
        position_list_surf_init, index_list_surf = get_position_list(self.dic_surf["coords_init"])
        self.dic_surf["position_list_init"] = position_list_surf_init
        self.dic_surf["index_list"] = index_list_surf

    def _get_species_surf_init(self):
        """
        Get initial atom species for surface
        """
        li_sp = []
        li_li_sp = []
        for indices in self.dic_surf["index_list"]:
            li_occup = [self.dic_surf["occup_init"][i] for i in indices]
            #li_atoms = [self.dic_surf["species"][i] for i in indices] 
            index_max = indices[li_occup.index(max(li_occup))]
            li_sp.append(self.dic_surf["species"][index_max])
            #li_li_sp.append(li_atoms)
        self.dic_surf["species_init"] = li_sp
        #self.dic_surf["species_list"] = li_li_sp

    def load_from_json(self, sub, surf):
        """
        Load substrate and surface data from JSON files generated by CTR-tool

        Arguments
        ---------
        sub : str
            JSON file for substrate
        surf : str
            JSON file for surface
        """
        # load substrate dict from json
        with open(sub) as f:
            dic_sub = json.load(f)
        key_np_list = ["coords"]
        for key in key_np_list:
            if key in dic_sub.keys():
                dic_sub[key] = [np.array(x) for x in dic_sub[key]]
        self.dic_sub = dic_sub

        # get lattice vectors from dic_sub["lattice"]
        if "lattice" in dic_sub.keys():
            self.lat_vec = get_lattice_vec(dic_sub["lattice"])
        
        # load surface dict from json
        with open(surf) as f:
            dic_surf = json.load(f)
        key_np_list = ["coords_init", "position_list_init"]
        for key in key_np_list:
            if key in dic_surf.keys():
                dic_surf[key] = [np.array(x) for x in dic_surf[key]]
        self.dic_surf = dic_surf

if __name__ == "__main__":
  substrate = "../sample/substrate.dat"
  surf = "../sample/surf.dat"
  json_substrate = "sub.json"
  json_surf = "surf.json"

  ctr = CTRtool(substrate, surf)

  print("## substrate coordinate ##")
  for i, sp in enumerate(ctr.dic_sub["species"]):
      x = ctr.dic_sub["coords"][i]
      print("{} {:.6f} {:.6f} {:.6f}".format(sp, x[0], x[1], x[2]))

  print("## surface coordinate ##")
  for i, sp in enumerate(ctr.dic_surf["species_init"]):
      x = ctr.dic_surf["position_list_init"][i]
      print("{} {:.6f} {:.6f} {:.6f}".format(sp, x[0], x[1], x[2]))
