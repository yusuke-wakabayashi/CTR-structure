"""
out_xyz.py
Output XYZ file from CTR-structure input files
"""
import json
import numpy as np
import periodictable as pt

from ctr_tool import CTRtool

def print_coords(species, coords, ix, iy, vec):
    """
    Print atom species and coordinates in the xyz-file style

    Arguments
    ---------
    species : list(str)
        List of atomic species
    coords : list(np.array)
        List of atomic coordinates
    ix : int
        x-index of the superlattice
    iy : int
        y-index of the superlattice
    vec : list(np.array)
        Lattice vectors
    """
    for i, sp in enumerate(species):
        x = coords[i] + ix*vec[0] + iy*vec[1]
        print("{} {:.6f} {:.6f} {:.6f}".format(sp, x[0], x[1], x[2]))

def print_cif(dic_sub, dic_surf, nx, ny):
    """
    Print CIF file

    Arguments
    ---------
    dic_sub : dict
        dictionary of substrate values
    dic_surf : dict
        dictionary of surface values
    nx : int
        size of superlattice (x-direction)
    ny : int
        size of superlattice (y-direction)
    """
    # get len_abc and angle_abc
    len_abc_tmp = [
            dic_sub["lattice"]["a"],
            dic_sub["lattice"]["b"],
            dic_sub["lattice"]["c"]
            ]

    zlist_surf = [x["z"]+(x["N"]-1)*x["d"] for x in dic_surf["atoms"]]
    maxval_surf = max(zlist_surf)

    x_abc = [nx, ny, (maxval_surf+1.0)*2]
    len_abc = [l*x_abc[i] for i, l in enumerate(len_abc_tmp)]
    angle_abc = [
            dic_sub["lattice"]["alpha"], 
            dic_sub["lattice"]["beta"], 
            dic_sub["lattice"]["gamma"]
            ]
    print("_cell_length_a {}".format(len_abc[0]))
    print("_cell_length_b {}".format(len_abc[1]))
    print("_cell_length_c {}".format(len_abc[2]))
    print("_cell_angle_alpha {}".format(angle_abc[0]))
    print("_cell_angle_beta {}".format(angle_abc[1]))
    print("_cell_angle_gamma {}\n".format(angle_abc[2]))
    print("_symmetry_space_group_name_H-M 'P 1'")
    print("_symmetry_Int_Tables_number 1\n")
    print("loop_")
    print("_symmetry_equiv_pos_as_xyz")
    print("   'x, y, z'\n")
    print("loop_")
    print("   _atom_site_label")
    print("   _atom_site_fract_x")
    print("   _atom_site_fract_y")
    print("   _atom_site_fract_z")
    print("   _atom_site_occupancy")
    # Output substrate atoms
    for ix in range(nx):
        for iy in range(ny):
            for atom in dic_sub["atoms"]:
                sp = str(pt.elements[atom["atomic_number"]])
                z = atom["z"]
                if z >= 1.0:
                    z -= int(z)
                frac_coord_tmp = [atom["x"]+float(ix), atom["y"]+float(iy), z]
                frac_coord = [f/x_abc[i] for i, f in enumerate(frac_coord_tmp)]
                print("   {} {} {} {} {}".format(sp, frac_coord[0], frac_coord[1], frac_coord[2], 1.0))

    # Output surface atoms
    for ix in range(nx):
        for iy in range(ny):
            for l in dic_surf["index_list"]:
                for ind in l:
                    sp = dic_surf["species"][ind]
                    tmp = dic_surf["coords_frac_init"][ind]
                    frac_coord_tmp = [tmp[0]+float(ix), tmp[1]+float(iy), tmp[2]+1.0]
                    frac_coord = [f/x_abc[i] for i, f in enumerate(frac_coord_tmp)]
                    occup = dic_surf["occup_init"][ind]
                    print("   {} {} {} {} {}".format(sp, frac_coord[0], frac_coord[1], frac_coord[2], occup))

class CTRjsonEncoder(json.JSONEncoder):
    """
    Json encoder for dicts of CTR-tool
    """
    def default(self, obj):
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        else:
            return super(CTRjsonEncoder, self).default(obj)

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        prog="out_xyz.py",
        description="Output XYZ file from CTR-structure input files."
    )

    parser.add_argument('sub', type=str, help='substrate data file for CTR-structure')
    parser.add_argument('surf', type=str, help='surface data file for CTR-structure')
    parser.add_argument('--json', action='store_true', help='output json data file or not')
    parser.add_argument('--cif', action='store_true', help='output CIF file instead of XYZ file')
    parser.add_argument('-x', dest='nx', type=int, default=1, help='size of superlattice (x-direction)')
    parser.add_argument('-y', dest='ny', type=int, default=1, help='size of superlattice (y-direction)')
    args = parser.parse_args()

    json_substrate = "sub.json"
    json_surf = "surf.json"

    ctr = CTRtool(args.sub, args.surf)
    if args.json:
        with open(json_substrate, "w") as f:
            json.dump(ctr.dic_sub, f, indent=4, cls=CTRjsonEncoder)
        with open(json_surf, "w") as f:
           json.dump(ctr.dic_surf, f, indent=4, cls=CTRjsonEncoder)

    if args.cif:
        print_cif(ctr.dic_sub, ctr.dic_surf, args.nx, args.ny)
    else:
        num_atoms = (len(ctr.dic_sub["species"]) + len(ctr.dic_surf["species_init"]))*args.nx*args.ny
        print(num_atoms)
        print("{} + {}, {} x {} (CTR-tool)".format(args.sub, args.surf, args.nx, args.ny))
        for ix in range(args.nx):
            for iy in range(args.ny):
                print_coords(ctr.dic_sub["species"], ctr.dic_sub["coords"], ix, iy, ctr.lat_vec)

        for ix in range(args.nx):
            for iy in range(args.ny):
                print_coords(ctr.dic_surf["species_init"], ctr.dic_surf["position_list_init"], ix, iy, ctr.lat_vec)
