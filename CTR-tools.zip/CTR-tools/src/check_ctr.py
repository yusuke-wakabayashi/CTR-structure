"""
check_ctr.py
Check CTR-structure input files
"""
from ctr_tool import *

def calc_dist2(x0, x1, lat_vec, nrange=[1, 1]):
    """
    Calculate distance^2 value between x0 and x1

    Arguments
    ----------
    x0 : np.array
        input vector 0 (len(x0)=3)
    x1 : np.array
        input vector 1 (len(x1)=3)
    lat_vec : list(np.array)
        list of lattice vectors
    nrange : list(int), default [1, 1]
        calculate distance in range [-lat_vec[0]*nrange[0], lat_vec[0]*nrange[0]]
        for 0-direction,  [-lat_vec[1]*nrange[1], lat_vec[1]*nrange[1]]
        for 1-direction

    Return
    -------
    min(dist2_list) : float
        distance between x0 and x1
    """
    dist2_list = []
    for i in range(-nrange[0], nrange[0]+1):
        for j in range(-nrange[1], nrange[1]+1):
            xx = x1 + i*lat_vec[0] + j*lat_vec[1]
            xx = xx - x0
            dist2_list.append(xx[0]**2+xx[1]**2+xx[2]**2)
    return min(dist2_list)

class CheckCTR():
    """
    Class for checking CTR-structure input files
    """
    def __init__(self, ctrtool):
        """
        Initialize CheckCTR class

        Argument
        --------
        ctrtool : CTRtool
            CTRtool class
        """
        self.ctr = ctrtool

    def check_all(self, eps):
        """
        Checking substrate and surface data

        Argument
        --------
        eps : float
            Allowed minimum distance (Ang)
        """
        print("Checking substrate and surface data...\n")
        self.check_dist_sub_surf(eps)
        self.check_dist_in_sub(eps)
        self.check_dist_in_surf(eps)
        print("Finished.")

    def check_dist_sub_surf(self, eps):
        """
        Checking distance between substrate and surface

        Argument
        --------
        eps : float
            Allowed minimum distance (Ang)
        """
        print("    Checking distance between substrate and surface...")
        # Get surface indices
        surf_pos_list = self.ctr.dic_surf["position_list_init"]
        lat_vec = self.ctr.lat_vec
        zlist_surf = [x[2] for x in surf_pos_list]
        zmin_surf = min(zlist_surf)
        surf_indices = []
        for i, z in enumerate(zlist_surf):
            if z <= zmin_surf + eps:
                surf_indices.append(i)

        # Get substrate indices
        sub_coords = self.ctr.dic_sub["coords"]
        zlist_sub = [x[2] for x in sub_coords]
        zmax_sub = max(zlist_sub)
        sub_indices = []
        for i, z in enumerate(zlist_sub):
            if z >= zmax_sub - eps:
                sub_indices.append(i)

        # Check distance
        all_ok = True
        for ind_surf in surf_indices:
            x_surf = np.array(surf_pos_list[ind_surf])
            for ind_sub in sub_indices:
                x_sub = np.array(sub_coords[ind_sub])
                dist2 = calc_dist2(x_surf, x_sub, lat_vec)
                if dist2 <= eps**2:
                    all_ok = False
                    index_list_surf = ctr.dic_surf["index_list"][ind_surf]
                    print("    Warning: substrate ({}) and surface ({}) are too close".format(ind_sub, index_list_surf))
        if all_ok:
            print("    OK.")

        print("")

    def check_dist_in_surf(self, eps):
        """
        Checking distance inside surface

        Argument
        --------
        eps : float
            Allowed minimum distance (Ang)
        """
        print("    Checking distance in surface...")
        surf_pos_list = self.ctr.dic_surf["position_list_init"]
        lat_vec = self.ctr.lat_vec
        len_s = len(surf_pos_list)
        all_ok = True
        for i in range(len_s):
            for j in range(len_s):
                if i < j:
                    x0 = np.array(surf_pos_list[i])
                    x1 = np.array(surf_pos_list[j])
                    dist2 = calc_dist2(x0, x1, lat_vec)
                    if dist2 <= eps**2:
                        all_ok = False
                        ind_list0 = ctr.dic_surf["index_list"][i]
                        ind_list1 = ctr.dic_surf["index_list"][j]
                        print("    Warning: surface ({}) and ({}) are too close".format(ind_list0, ind_list1))
        if all_ok:
            print("    OK.")

        print("")

    def check_dist_in_sub(self, eps):
        """
        Checking distance inside substrate

        Argument
        --------
        eps : float
            Allowed minimum distance (Ang)
        """
        print("    Checking distance in substrate...")
        sub_coords = self.ctr.dic_sub["coords"]
        lat_vec = self.ctr.lat_vec
        len_s = len(sub_coords)
        all_ok = True
        for i in range(len_s):
            for j in range(len_s):
                if i < j:
                    x0 = np.array(sub_coords[i])
                    x1 = np.array(sub_coords[j])
                    dist2 = calc_dist2(x0, x1, lat_vec)
                    if dist2 <= eps**2:
                        all_ok = False
                        print("    Warning: substrate ({}) and ({}) are too close".format(i, j))
        if all_ok:
            print("    OK.")

        print("")

    def out_coord_surf(self, fname):
        """
        Output atomic species and coordinates in surface data file

        Argument
        --------
        fname : str
            Filename of surface data
        """
        print("Output atomic species and coordinates in {}".format(fname))
        atoms = self.ctr.dic_surf["atoms"]
        for i, l in enumerate(self.ctr.dic_surf["index_list"]):
            coord = ["{:.5f}".format(x) for x in self.ctr.dic_surf["position_list_init"][i]]
            atom_list = ["{}({})".format(self.ctr.dic_surf["species"][ind], ind) for ind in l]
            print("    {}: {} at ({}, {}, {})".format(i, atom_list, coord[0], coord[1], coord[2]))
        
        print("")

    def out_coord_sub(self, fname):
        """
        Output atomic species and coordinates in substrate data file

        Argument
        --------
        fname : str
            Filename of substrate data
        """
        print("Output atomic species and coordinates in {}".format(fname))
        atoms = self.ctr.dic_sub["atoms"]
        coords = self.ctr.dic_sub["coords"]
        for i, atom in enumerate(atoms):
            coord = ["{:.5f}".format(x) for x in coords[i]]
            atom_sp = pt.elements[atom["atomic_number"]]
            print("    {}: {} at ({}, {}, {})".format(i, atom_sp, coord[0], coord[1], coord[2]))
        
        print("")

if __name__ == "__main__":
    from ctr_tool import CTRtool
    import argparse

    parser = argparse.ArgumentParser(
        prog="check_ctr.py",
        description="Check CTR-structure input files."
    )

    parser.add_argument('sub', type=str, help='substrate data file for CTR-structure')
    parser.add_argument('surf', type=str, help='surface data file for CTR-structure')
    parser.add_argument('-t', '--threshold', type=float, default=1.0,
            help='allowed minimum distance (Ang)')
    parser.add_argument('--out_coord', action='store_true', help='Output coordinates and atoms in sub and surf')

    args = parser.parse_args()

    ctr = CTRtool(args.sub, args.surf)
    check = CheckCTR(ctr)

    if args.out_coord:
        check.out_coord_sub(args.sub)
        check.out_coord_surf(args.surf)

    check.check_all(args.threshold)

